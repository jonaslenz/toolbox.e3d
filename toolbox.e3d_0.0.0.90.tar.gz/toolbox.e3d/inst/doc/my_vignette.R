## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)


## ---- eval = FALSE------------------------------------------------------------
#  system2("e3d", '/c "C:/E3Dmodel/model/run.par"', wait=TRUE)

## ---- eval = FALSE------------------------------------------------------------
#  # Install devtools from CRAN
#  install.packages("devtools")
#  
#  # Install toolbox.e3d
#  devtools::install_github("jonaslenz/toolbox.e3d")

## -----------------------------------------------------------------------------
toolbox.e3d::get_version.E3D()

## -----------------------------------------------------------------------------
skin_cum <-
toolbox.e3d::determine.skin.runoff.E3D(Cl = 30, Si = 40, Sa = 30,
                          Corg = 1.3, Bulk = 1300, Moist = 22,
                          CumRunoff = 100, intensity = 0.5,
                          plotwidth = 1, plotlength = 10,
                          slope = 10,
                          endmin = 30,
                          ponding = TRUE, silent = FALSE)
skin_cum

## -----------------------------------------------------------------------------
skin_inf <-
toolbox.e3d::determine.skin.infil.E3D(Cl = 30, Si = 40, Sa = 30,
                         Corg = 1.3, Bulk = 1300, Moist = 22,
                         infilrate = 0.2, intensity = 0.5,
                         plotwidth = 1, plotlength = 10,
                         slope = 10,
                         endmin = 30,
                         ponding = TRUE, silent = FALSE)
skin_inf

## -----------------------------------------------------------------------------
eros_cum <-
  toolbox.e3d::determine.eros.cumsed.E3D(FCl=5,MCl=10,CCl=15,
                                       FSi=10,MSi=20,CSi=10,
                                       FSa=15,MSa=10,CSa=5,
                                       Corg = 1.3, Bulk = 1300, Moist = 22,
                                       Skin = skin_cum, Roughness=0.05, Cover = 20,
                                       Soilloss = 1,
                                       intensity = 0.5, plotwidth = 1,
                                       plotlength = 10, slope = 10,
                                       endmin = 30, ponding = TRUE, silent = F)
eros_cum

## -----------------------------------------------------------------------------
path <- toolbox.e3d::create_folders.E3D(path = "C:/E3Dmodel_toolbox/")

## -----------------------------------------------------------------------------
soils <- read.csv(file.path(path,"soil/soil_params.csv"))[1,]

# soil parameters are set according to example in parameter determination
  soils$BLKDENSITY <- 1300
  soils$CORG       <- 1.3
  soils$INITMOIST  <- 22
  soils$FT         <- 5
  soils$MT         <- 10
  soils$GT         <- 15
  soils$FU         <- 10
  soils$MU         <- 20
  soils$GU         <- 10
  soils$FS         <- 15
  soils$MS         <- 10
  soils$GS         <- 5
  soils$ROUGHNESS  <- 0.05
  soils$COVER      <- 20
  soils$ERODIBIL   <- eros_cum
      
# parameters derived automaticly by EROSION-3D are set to 0
  soils$THETA_R <- 0
  soils$THETA_S <- 0
  soils$ALPHA <- 0
  soils$NORDPOL <- 0

# a second soil parameter entry is created
  soils[2,] <- soils[1,]

# ID of second entry is set
  soils$POLY_ID<- 1:nrow(soils)

# skinfactors are set for each entry separately
  soils$SKINFACTOR[1] <- skin_cum
  soils$SKINFACTOR[2] <- skin_inf
  
  write.csv(soils,file.path(path,"soil/soil_params.csv"),
            row.names = FALSE, quote = FALSE)

## -----------------------------------------------------------------------------
  toolbox.e3d::write.landuse.E3D(POLY_ID = soils$POLY_ID, length = 10,
            path = file.path(path,"soil/"), filename = "landuse.asc")

## -----------------------------------------------------------------------------
# write files to parent folder
  write.csv(soils,file.path(path,"soil_params.csv"),
            row.names = FALSE, quote = FALSE)
  toolbox.e3d::write.landuse.E3D(POLY_ID = soils$POLY_ID, length = 10,
            path = file.path(path), filename = "landuse.asc")

# read, modify and rewrite *.par
  run_par <- ini::read.ini(file.path(path,"run.par"))
  run_par[["Soil_landuse"]][["rdb_dat"]] <- file.path(path,"soil_params.csv")
  run_par[["Soil_landuse"]][["rdb_grd"]] <- file.path(path,"landuse.asc")
  ini::write.ini(run_par,filepath = file.path(path,"run.par"))

# preprocess soil set
  system2("e3d", paste0('/s "',normalizePath(file.path(path,"run.par")),'"'), wait=TRUE)
  

## ---- include=F---------------------------------------------------------------
# read resulting soil_params
  soilsbyE3D <- read.csv(file.path(path,"soil/soil_params.csv"))

## -----------------------------------------------------------------------------
toolbox.e3d::write.relief.E3D(POLY_ID = soils$POLY_ID, length = 10,slope = 11,
                              path = path, filename = "dem.asc")

## -----------------------------------------------------------------------------
system2("e3d", paste0('/r "',normalizePath(file.path(path,"run.par")),'"'), wait=TRUE)

## -----------------------------------------------------------------------------
slope_E3D <- raster::raster(normalizePath(file.path(path,"relief/slope.asc")))
unique(raster::values(slope_E3D))

## -----------------------------------------------------------------------------
# 30 minutes * 60 seconds/minute
toolbox.e3d::write.rainfile.E3D(time = c(0,30*60), intens = c(0.5,0), path,
                                filename = "rain_e3d.csv")

## -----------------------------------------------------------------------------
system2("e3d", paste0('/c "',normalizePath(file.path(path,"run.par")),'"'), wait=TRUE)

## -----------------------------------------------------------------------------
#read runoff in litres (*1000)
runoff <- raster::raster(file.path(path,"result/sum_q.asc"))[,1]*1000
sed <- raster::raster(file.path(path,"result/sum_sedvol.asc"))[,1]

cbind(soils[,c("POLY_ID","SKINFACTOR")], runoff, sed)

## -----------------------------------------------------------------------------
unlink(file.path("C:/E3Dmodel_toolbox/"), force = T, recursive = T)

